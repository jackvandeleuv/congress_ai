import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// const SUPABASE_URL = "REMOVED_HARDCODED_API_KEY"
// const SUPABASE_KEY = "REMOVED_HARDCODED_API_KEY"
// // https://vitejs.dev/config/
// export default defineConfig({
//   plugins: [react()],
//   server: {
//     proxy: {
//       '/api': {
//         target: 'http://localhost:8000',
//         rewrite: (path) => path.replace('/api', '')
//       }
//     }
//   },
//   define: {
//     // This will be replaced with your actual Supabase URL during build
//     'import.meta.env.SUPABASE_URL': JSON.stringify(SUPABASE_URL),
//     'import.meta.env.SUPABASE_KEY': JSON.stringify(SUPABASE_KEY),
//   },
// });

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/congressgpt': 'http://127.0.0.1:8000',
      '/api': {
        target: 'http://127.0.0.1:8000',
        rewrite: (path) => path.replace('/api', '')
      }
    }
  }
});


